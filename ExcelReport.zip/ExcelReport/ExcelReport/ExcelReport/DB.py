import pyhdb

class DBManager(object):
    instance = None

    @staticmethod
    def get_instance():
        if DBManager.instance is None:
            DBManager.instance = DBManager()
        return DBManager.instance

    def __init__(self):
        self.hana_address = "10.58.114.74"
        self.schema = "SBODEMOUS"
        self.port = 30015
        self.connection = None
        self.connection = pyhdb.connect(host=self.hana_address,
                                        port=self.port,
                                        user="SYSTEM",
                                        password="manager")

    def retrieve_report_list(self):

        cursor = self.connection.cursor()
        sql = 'SELECT "ReportId", "Title" FROM SBODEMOUS.OIRD ' \
              'WHERE "Type"=1'
        try:
            cursor.execute(sql)
            query_result = cursor.fetchall()
        except Exception as exp:
            print("oops! Exception occurs:" , exp)
            return None

        context = dict()
        for (rid, rname) in query_result:
            context[rid] = rname

        # self.connection.close()
        return context

    def retrieve_view_measures(self):
        cursor = self.connection.cursor()
        sql = 'SELECT "MEASURE_NAME" FROM  "_SYS_BI"."BIMC_MEASURES" ' \
              'where catalog_name like \'sap.{}%\' and ' \
              'cube_name like \'SalesAnalysisQuery\' ' \
              'Order by MEASURE_NAME'.format(self.schema.lower())
        print("Get report measures:{}".format(sql))
        try:
            cursor.execute(sql)
            measures = cursor.fetchall()
            mesures_list = list()
            for (m,) in measures:
                mesures_list.append(m)

            return mesures_list
        except Exception as exp:
            print("Opps! Exception ->", exp)
            return list()

    def retrieve_view_dimensions(self):
        cursor = self.connection.cursor()
        sql = 'SELECT DIMENSION_NAME FROM "_SYS_BI"."BIMC_ALL_DIMENSIONS" ' \
              'where catalog_name like \'sap.{}%\' and cube_name ' \
              'like \'SalesAnalysisQuery\' and ' \
              '"DIMENSION_TYPE"=3 ORDER BY DIMENSION_NAME'.format(self.schema.lower())
        print("fetch dimensions: ", sql)

        try:
            cursor.execute(sql)
            dimensions = cursor.fetchall()
            dimension_list = list()
            for (d,) in dimensions:
                dimension_list.append(d)
            return dimension_list

        except Exception as exp:
            print("Opps! -> ", exp)
            return list()


if __name__ == '__main__':
    db = DBManager()
    context = db.retrieve_report_list()
    print(context)
