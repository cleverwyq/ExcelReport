class FolderItem:
    def __init__(self):
        self.display_name = ''
        self.is_folder = 'F'

    def set_display_name(self, value):
        self.display_name = value

    def set_is_folder(self, value):
        self.is_folder = value
